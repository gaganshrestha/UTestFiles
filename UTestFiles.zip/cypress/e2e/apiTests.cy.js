/// <reference types="cypress" />

const petStoreBaseUrl = 'https://petstore.swagger.io/v2'
let requestBody //holds the request body json defined in the fixture
let petId //holds the pet id of the one created for this test and will be used for rest of the function

describe('Swagger Pet Store - API Tests', () => {

  before(() => {
    cy.fixture('requestBody').then(data => { 
      //iniatilise request body from the fixture
      requestBody = data

      //generate random pet id
      petId = Math.floor(Math.random() * Cypress._.now())

      //populate the request body with the generated id
      requestBody.addPet["id"]= petId
      requestBody.updatePetName["id"]= petId

      //create a pet record to use for the rest of the test
      cy.request({
        method: 'POST', 
        url: `${petStoreBaseUrl}/pet`,         
        headers: {
          accept: 'application/json'
        },
        body: requestBody.addPet
      })
        .then( (response) => {  
          expect(response.status).to.eq(200)   
          expect(response.body.id).to.eq(petId)
          expect(response.body).to.deep.eq(requestBody.addPet)
      })
    })
  })
 
  it('Find pet by id', () => {
    cy.request({
      method: 'GET', 
      url: `${petStoreBaseUrl}/pet/${petId}`,
      failOnStatusCode: false,             
      headers: {
        accept: 'application/json'
      }      
    })
    .then( (response) => {  
      expect(response.status).to.eq(200)    
      expect(response.body.id).to.eql(petId)
      expect(response.body).to.deep.eq(requestBody.addPet)
    })
  })

  it('Update pet name', () => {
    cy.request({
      method: 'PUT', 
      url: `${petStoreBaseUrl}/pet`, 
      failOnStatusCode: false,         
      headers: {
        accept: 'application/json',
      },
      body: requestBody.updatePetName
    })
    .then( (response) => {  
      console.log(response)
      expect(response.status).to.eq(200)    
      expect(response.body.id).to.eql(petId)
      expect(response.body).to.deep.eq(requestBody.updatePetName)

    })
    .then( (response) => {
      //query the pet by id and verify the pet name is changed
      cy.log(response)
      cy.request({
        method: 'GET', 
        url: `${petStoreBaseUrl}/pet/${petId}`,     
        failOnStatusCode: false,    
        headers: {
          accept: 'application/json'
        }      
      })
      .then( (response) => {  
        console.log(response)
        expect(response.status).to.eq(200)    
        expect(response.body).to.deep.eq(requestBody.updatePetName)

      })
    })
  })

  it('Delete pet', () => {
    cy.request({
      method: 'DELETE', 
      url: `${petStoreBaseUrl}/pet/${petId}`,  
      failOnStatusCode: false,       
      headers: {
        accept: 'application/json',
        api_key: "special_key"
      },
    })
    .then( (response) => {  
      expect(response.status).to.eq(200)
      expect(response.body.message).to.eq(`${petId}`)   
          
    }).then(() => {
        //query the pet by id and verify the pet is not found - Error 404
        cy.request({
          method: 'GET', 
          url: `${petStoreBaseUrl}/pet/${petId}`,     
          failOnStatusCode: false,    
          headers: {
            accept: 'application/json'
          }      
        })
        .then( (response) => {  
          expect(response.status).to.eq(404) 
        })
      })
  })

})

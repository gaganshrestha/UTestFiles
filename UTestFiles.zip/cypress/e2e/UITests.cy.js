/// <reference types="cypress" />

import * as loginPageSelectors from '../support/loginPageSelectors'
import * as landingPageSelectors from '../support/landingPageSelectors'


describe('UBank - UI Tests', () => {
  beforeEach(() => {
    cy.visit(Cypress.config("baseUrl"))
  })

  it('Ubank - Landing page links validation', () => {
    cy.contains(loginPageSelectors.LINK_BUTTON,"Log in").should("exist")
    cy.contains(loginPageSelectors.LINK_BUTTON,"Apply now").should("exist")
  })

  it('Ubank - Login page validation', () => {
    cy.contains(landingPageSelectors.LINK_BUTTON,"Log in").click()
    cy.get(landingPageSelectors.LOGIN_USERNAME_FIELD).type("Existing_User")
    cy.get(landingPageSelectors.LOGIN_SIGNUP_LINK).contains('a','Sign up with ubank').should('have.attr','href').then(href => {
      expect(href).contains('/welcome/login/onboard-first')
    })
    cy.contains(landingPageSelectors.LOGIN_NEXT_BUTTON, "Next").should("exist")    
  })
})

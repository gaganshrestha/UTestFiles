/***** Landing page ************************/
export const LINK_BUTTON = '[sp-automation-id=fe-block-link-button]'


/***** Login page ************************/
export const LOGIN_USERNAME_FIELD = 'input[sp-automation-id=input-username]'
export const LOGIN_SIGNUP_LINK = '[sp-automation-id=login-username-page-join-link]'
export const LOGIN_NEXT_BUTTON = '[sp-automation-id=sp-form-submit-button]'